function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6kiainPCT77":
        Script1();
        break;
      case "67mlaC6LDwG":
        Script2();
        break;
      case "6Pi6XJtMoyZ":
        Script3();
        break;
      case "5YTP4AJIPGG":
        Script4();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
var getKeyDown = player.getKeyDown;
var keydown = player.keydown;
var keyup = player.keyup;
window.Script1 = function()
{
  const target = object('6cw778ojMa1');
const duration = 750;
const easing = 'ease-out';
const id = '6qJMGYaH4i9';
const bounceAmount = 1;
player.addForTriggers(
id,
target.animate(
player.emphasis.bounce(bounceAmount)
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('5gtTQLsW509');
const duration = 750;
const easing = 'ease-out';
const id = '5mxmQKxiHqz';
const floatAmount = 5;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('5gtTQLsW509');
const duration = 750;
const easing = 'ease-out';
const id = '5mxmQKxiHqz_reverse';
const floatAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {translate: `0 -${floatAmount}px` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('64azPII8LHA');
const duration = 750;
const easing = 'ease-out';
const id = '5q88B2tpDML';
const growAmount = 0.2;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

};
